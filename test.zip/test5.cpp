#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
	char a[5000];
	cin>>a;
	for(int i=0;i<strlen(a);i++){
		if(a[i]=='N'||a[i]=='n'){
			if(a[i+1]=='O'||a[i+1]=='o'){
				if(a[i+2]=='I'||a[i+2]=='i'){
					if(a[i+3]=='P'||a[i+3]=='p'){
						a[i]='C';
						a[i+1]='S';
						a[i+2]='P';
						a[i+3]=' ';
					}
				}
			}
		}
	}
	for(int i=0;i<strlen(a);i++){
		if(a[i]!=' '){
			cout<<a[i];
		}
	}
}

