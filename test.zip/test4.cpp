#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
	double x,y,t;
	cin>>x>>y>>t;;
	long long p=ceil(x/y);
	if(p==t){
		cout<<p<<endl;
	}else{
		long long k=floor(p/t);
		if(p/t==k){
			k-=1;
		} 
		cout<<k*5+p<<endl;
	}
}

