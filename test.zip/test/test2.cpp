#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
	    for(int z=n-i-2;z>=0;z--){
	    	cout<<" ";
		}
		if(i==0){
			cout<<"*";
			cout<<endl;
			continue;
		} 
		if(i==n-1){
			for(int j=1;j<=2*i+1;j++){
			cout<<"*";
		}
		return 0;
		}
		cout<<"*";
		for(int j=1;j<=2*i-1;j++){
			cout<<"#";
		}
		cout<<"*";
		cout<<endl;
	}
}
