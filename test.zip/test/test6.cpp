#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int n,i,ans=0;
int vis[10];
int a[10];
bool flag=false;
void DFS(int x){
	if(x==i){
		ans++;
		if(ans==n){
			for(int j=0;j<i;j++){
				cout<<a[j]<<" ";
			}
			flag=true;
		}
		return;
	}else{
		for(int j=1;j<=i;j++){
			if(!vis[j]){
				vis[j]=1;
				a[x]=j;
				DFS(x+1);
				vis[j]=0;
			}
		}
	}
}
int main(){
	cin>>n;
	for(i=1;i<=n;i++){
		DFS(0);
		if(flag){
			return 0;
		}
	}
}

