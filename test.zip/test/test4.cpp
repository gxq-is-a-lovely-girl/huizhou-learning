#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
long long n,m,arr[100005],vis[100005]={0},l,r;
int main(){
    cin>>n>>m;
    for(int i=1;i<=n;i++){
    	cin>>arr[i];
    	vis[i]+=arr[i];
    	vis[i+1]+=vis[i];
	}
    for(int i=0;i<m;i++){
    	cin>>l>>r;
		cout<<vis[r]-vis[l-1]<<endl;
	}
    return 0;
}
