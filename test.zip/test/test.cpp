#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
	double n,m;
	cin>>n>>m;
	cout<<ceil(n/m);
}

