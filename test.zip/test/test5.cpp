#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
bool tmp(int a,int b){
	return a>b;
}
int main(){
	char a[20]={0};
	cin>>a;
	int k[20];
	for(int i=0;i<strlen(a);i++){
		k[i]=a[i]-'0';
	}
	sort(k,k+strlen(a),tmp);
	for(int i=0;i<strlen(a);i++){
		cout<<k[i];
	}
		cout<<" ";
	int min1=INT_MAX;
	int l; 
	for(int i=0;i<strlen(a);i++){
		if(k[i]<min1&&k[i]!=0){
			min1=k[i];
			l=i;
		}
	}
	cout<<k[l];
	min1=k[l];
	bool o=false;
	sort(k,k+strlen(a));
	for(int i=0;i<strlen(a);i++){
		if(k[i]==min1&&o==false){
			o=true;
			continue;
		}
		cout<<k[i];
	}

	
}

