#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
		long long x;
		cin>>x;
		if(x<-15){
			cout<<-1*x+1;
			return 0;
		}else if(-15<=x&&x<=40){
			cout<<x*(x-2);
			return 0; 
		}else if(x>40){
			cout<<2*x-3;
			return 0;
		}
}

