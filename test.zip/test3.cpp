#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
 	long long n;
 	cin>>n;
 	long long sum=0;
 	for(long long i=1;i<=sqrt(n);i++){
 		if(n%i==0){
 			sum+=i;
 			if(i==1){
 				continue;
			 }else{
			 	sum+=n/i;
			 }
 			
		 }
	 }
	 if(sum==n){
	 	cout<<"Yes.";
	 }else{
	 	cout<<"No.";
	 }
}

