#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<climits>
#include<cstring>
using namespace std;
int main(){
	int n;
	cin>>n;
	if(n%2==0&&n>20){
		cout<<"Lucky!";
	}else{
		cout<<"Not bad!"<<endl;
		cout<<"Go ahead!";
	}
}

